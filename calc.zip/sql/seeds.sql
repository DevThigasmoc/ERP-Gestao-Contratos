INSERT INTO users (nome, email, password_hash, perfil, ativo, created_at, updated_at)
VALUES ('Administrador', 'admin@kavvi.com', '$2y$12$k27ve6dWnTgIxvyRqpnJ.uSbWfb20YyUuhdRDWy41JQLtdLAE7edy', 'admin', 1, NOW(), NOW());
