<?php
return [
  'db' => [
    'host' => 'localhost',
    'name' => 'u350942708_calc',
    'user' => 'u350942708_calc',
    'pass' => '475869F0nsec@',
    'charset' => 'utf8mb4'
  ],
];
